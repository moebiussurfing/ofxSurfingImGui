# ImTools
Dear ImGui Widgets/Tools i used in my projects

## [LayoutManager](LayoutManager) :

its a class for manage docking panes in a easy way, display (panes, menu, pane dialog), load/save, autolayout, etc...

see LayoutManager directory
you have also a sample app
