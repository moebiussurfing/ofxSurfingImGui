In random order:
* Documentation: Make one

Done:
* ~~ImGui: Factor out changes to ImGui to use vanilla version.~~
* ~~Editor: Fix variable naming (mainly add `m_` prefix)~~
* ~~Editor: Split NodeEditorImpl.cpp to multiple files, file has grown too big.~~
* ~~Editor: Factor out use of `picojson.h`~~
* ~~Editor: Move use of `<optional>` to optional code extensions~~




#57 - join `ax::NodeEditor::EditorContext` with `struct EditorContext` and remove `reinterpret_cast<>`