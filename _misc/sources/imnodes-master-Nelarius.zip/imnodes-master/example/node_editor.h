#pragma once

namespace example
{
void NodeEditorInitialize();
void NodeEditorShow();
void NodeEditorShutdown();
} // namespace example